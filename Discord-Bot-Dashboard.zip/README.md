# Discord-Bot-Dashboard
Simple Discord dashboard of different pages
# Bot Dashboaard
A sample responsive website for your Discord bot

# Demo: https://bot-site.gamingdiwas.repl.co

I have spent a lot of time doing this, so I would really appreciate if you would leave me a star.

You can else visit my youtube: https://www.youtube.com/channel/UCo2iuPS4FZ8V6H_ct2F8-2A

Thank you and have a nice day/afternoon/night

## Info

Author: Romeo#0700
License: MIT License
Time working: About 5 hours
Made using: HTML5, CSS3, JavaScript
Text Editor: Repl.it
